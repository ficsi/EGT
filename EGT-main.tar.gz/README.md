
# node & npm versions on the time of writing
    node -v: v16.15.0
    npm -v: 8.5.5

## RUN auto formatter
``npm run formatter``


### added pre-defined `.eslintrc` configuration
    - in case of errors returned needs to run `eslint --fix` to automatically fixes or check it manually

### To start the project you need to run
- npm install
- npm run start
