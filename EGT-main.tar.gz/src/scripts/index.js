import '../styles/main.scss';
import './components/popup';
import './components/slider';
import './components/dropdown';
import './components/add-active-class';
